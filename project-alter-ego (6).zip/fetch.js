const https = require('https');
https.get('https://019ea5f5-2b44-7067-814d-a28ed144cbd9.arena.site/', (resp) => {
  let data = '';
  resp.on('data', (chunk) => { data += chunk; });
  resp.on('end', () => { console.log(data); });
}).on("error", (err) => { console.log("Error: " + err.message); });
