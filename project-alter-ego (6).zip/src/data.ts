import { OnboardingQuestion, FutureScene } from './types';

export const ONBOARDING_QUESTIONS: OnboardingQuestion[] = [
  {
    id: 'memory-1',
    category: 'The Turn',
    question: 'Imagine you\'re looking back from a future where it all worked out.',
    description: 'What finally changed? Where are you sitting right now?',
    type: 'text',
  },
  {
    id: 'memory-2',
    category: 'The Witness',
    question: 'Who is standing in the room with you?',
    description: 'What do they say? Or do they just look at you differently?',
    type: 'text',
  },
  {
    id: 'memory-3',
    category: 'The Quiet Pride',
    question: 'What small, normal moment suddenly feels completely different?',
    description: 'E.g., buying coffee without checking your balance, or your parents showing off your work casually.',
    type: 'text',
  },
  {
    id: 'sabotage',
    category: 'The Resistance',
    question: 'What is the quiet lie you tell yourself today to justify giving up?',
    description: 'Be brutally honest.',
    options: ['"I still have time."', '"I need to be perfectly ready first."', '"It probably won\'t work anyway."', '"I\'m just too tired right now."'],
    type: 'multi-choice',
  }
];

export const FUTURE_SCENES: FutureScene[] = [
  {
    id: 'fs-1',
    type: 'Quiet Pride',
    context: 'Tuesday — 8:32 AM',
    content: "You buy coffee.\n\nNo hesitation.\n\nNo checking your account first.\n\nIt hits you halfway through the walk:\n\nthings changed."
  },
  {
    id: 'fs-2',
    type: 'Validation',
    context: 'Saturday — 10:14 PM',
    content: "Someone behind you says:\n\n\"Wait… he actually made this?\"\n\nYou pretend not to hear.\n\nBut you do."
  },
  {
    id: 'fs-3',
    type: 'Relief',
    context: 'Living room — 9:18 PM',
    content: "Your dad shows someone your interview.\n\nCasually.\n\nLike he’s done it a hundred times before.\n\nYou quietly sip your water."
  },
  {
    id: 'fs-4',
    type: 'Aspiration',
    context: 'Thursday — 11:42 PM',
    content: "You're packing up the old apartment.\n\nYou find the dusty notebook where you wrote the original idea.\n\nYou trace the ink.\n\nYou didn't quit."
  }
];
