import { useState } from 'react';
import { ONBOARDING_QUESTIONS, FUTURE_SCENES } from '../data';
import { motion, AnimatePresence } from 'motion/react';

type Step = 'prologue' | 'onboarding' | 'analyzing' | 'artifact';

export function MVPView() {
  const [step, setStep] = useState<Step>('prologue');
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [inputText, setInputText] = useState('');
  const [activeSceneId, setActiveSceneId] = useState<string | null>(null);

  const activeScene = activeSceneId ? FUTURE_SCENES.find(s => s.id === activeSceneId) : null;

  const handleNextQuestion = () => {
    const q = ONBOARDING_QUESTIONS[currentQuestionIdx];
    if (q.type === 'text' && inputText) {
      setAnswers(prev => ({ ...prev, [q.id]: inputText }));
    }
    
    setInputText('');
    advanceOnboarding();
  };

  const handleOptionSelect = (option: string) => {
    const q = ONBOARDING_QUESTIONS[currentQuestionIdx];
    setAnswers(prev => ({ ...prev, [q.id]: option }));
    advanceOnboarding();
  };

  const advanceOnboarding = () => {
    if (currentQuestionIdx < ONBOARDING_QUESTIONS.length - 1) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      setStep('analyzing');
      setTimeout(() => {
        setStep('artifact');
        setActiveSceneId(FUTURE_SCENES[0].id);
      }, 7000);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center px-6 antialiased font-sans bg-black">
      <AnimatePresence mode="wait">

      {step === 'prologue' && (
        <motion.div 
          key="prologue"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, filter: "blur(10px)" }}
          transition={{ duration: 2 }}
          className="flex flex-col items-center justify-center max-w-2xl mx-auto w-full text-center min-h-[80vh]"
        >
          <div className="flex flex-col items-center justify-center space-y-24">
            <motion.p 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 3, delay: 1 }}
              className="text-white/30 font-serif italic text-lg"
            >
              A memory from your future just arrived.
            </motion.p>
            
            <div className="space-y-8">
              <motion.p initial={{ opacity: 0, filter: "blur(4px)", y: 5 }} animate={{ opacity: 1, filter: "blur(0px)", y: 0 }} transition={{ duration: 3, delay: 5.5 }} className="font-mono text-[9px] tracking-[0.4em] uppercase text-white/30">
                Friday — 11:42 PM
              </motion.p>
              <div className="space-y-4 pt-4">
                <motion.p initial={{ opacity: 0, filter: "blur(4px)" }} animate={{ opacity: 1, filter: "blur(0px)" }} transition={{ duration: 3, delay: 8 }} className="font-serif text-2xl md:text-3xl font-light text-white/90">
                  You're locking your office.
                </motion.p>
                <motion.p initial={{ opacity: 0, filter: "blur(4px)" }} animate={{ opacity: 1, filter: "blur(0px)" }} transition={{ duration: 3, delay: 11 }} className="font-serif text-2xl md:text-3xl font-light text-white/90">
                  Everyone already left.
                </motion.p>
                <motion.p initial={{ opacity: 0, filter: "blur(4px)" }} animate={{ opacity: 1, filter: "blur(0px)" }} transition={{ duration: 3, delay: 14 }} className="font-serif text-2xl md:text-3xl font-light text-white/90">
                  You stop for a second.
                </motion.p>
                <motion.p initial={{ opacity: 0, filter: "blur(4px)" }} animate={{ opacity: 1, filter: "blur(0px)" }} transition={{ duration: 3, delay: 17 }} className="font-serif text-2xl md:text-3xl font-light text-white/90">
                  Funny thing?
                </motion.p>
                <motion.p initial={{ opacity: 0, filter: "blur(4px)" }} animate={{ opacity: 1, filter: "blur(0px)" }} transition={{ duration: 3, delay: 20 }} className="font-serif text-2xl md:text-3xl font-light text-white/90">
                  You still remember when this was only an idea.
                </motion.p>
              </div>
            </div>

            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 3, delay: 24 }}
              onClick={() => setStep('onboarding')}
              className="group pt-12 relative cursor-pointer"
            >
              <span className="relative z-10 flex items-center space-x-6 pb-3 border-b border-white/10 group-hover:border-white/40 transition-colors duration-1000">
                <span className="font-mono text-[9px] tracking-[0.3em] uppercase text-white/30 group-hover:text-white/80 transition-colors duration-1000">Continue Becoming</span>
                <div className="w-4 h-[1px] bg-white/20 group-hover:bg-white/80 group-hover:w-8 transition-all duration-1000" />
              </span>
            </motion.button>
          </div>
        </motion.div>
      )}

      {step === 'onboarding' && (
        <motion.div 
          key="onboarding"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, filter: "blur(10px)" }}
          transition={{ duration: 2, ease: "easeInOut" }}
          className="max-w-xl w-full mx-auto flex flex-col justify-center min-h-[70vh]"
        >
          <AnimatePresence mode="wait">
            <motion.div 
              key={currentQuestionIdx}
              initial={{ opacity: 0, y: 10, filter: "blur(8px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -10, filter: "blur(8px)" }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="w-full"
            >
              <div className="mb-16 text-center">
                <h2 className="font-serif text-3xl md:text-4xl font-light leading-relaxed mb-6 text-white/90">
                  {ONBOARDING_QUESTIONS[currentQuestionIdx].question}
                </h2>
                <p className="font-serif text-lg md:text-xl font-light text-white/30 italic">
                  {ONBOARDING_QUESTIONS[currentQuestionIdx].description}
                </p>
              </div>

              {ONBOARDING_QUESTIONS[currentQuestionIdx].type === 'text' && (
                <div className="space-y-12 max-w-md mx-auto">
                  <textarea
                    autoFocus
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Type quietly..."
                    className="w-full bg-transparent border-b border-white/10 pb-4 text-center text-white/80 placeholder-white/20 focus:outline-none focus:border-white/30 focus:ring-0 resize-none h-20 transition-colors font-serif text-xl md:text-2xl font-light leading-relaxed italic"
                  />
                  <div className="flex justify-center">
                    <button
                      onClick={handleNextQuestion}
                      disabled={!inputText.trim()}
                      className="group flex flex-col items-center space-y-4 disabled:opacity-0 transition-opacity duration-1000"
                    >
                      <div className="w-px h-6 bg-white/20 group-hover:h-10 group-hover:bg-white/60 transition-all duration-700" />
                      <span className="text-[9px] font-mono tracking-[0.4em] uppercase text-white/40 group-hover:text-white/80 transition-colors duration-700">Commit</span>
                    </button>
                  </div>
                </div>
              )}

              {ONBOARDING_QUESTIONS[currentQuestionIdx].type !== 'text' && (
                <div className="space-y-4 max-w-md mx-auto">
                  {ONBOARDING_QUESTIONS[currentQuestionIdx].options?.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => handleOptionSelect(opt)}
                      className="w-full py-6 text-center border-b border-transparent hover:border-white/10 transition-colors duration-700 group flex flex-col items-center space-y-4"
                    >
                      <span className="text-xl md:text-2xl font-serif font-light text-white/40 group-hover:text-white/90 transition-colors duration-700">{opt}</span>
                    </button>
                  ))}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </motion.div>
      )}

      {step === 'analyzing' && (
        <motion.div 
          key="analyzing"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, filter: "blur(10px)" }}
          transition={{ duration: 2 }}
          className="flex flex-col items-center justify-center max-w-md mx-auto min-h-[60vh] text-center"
        >
          <div className="space-y-16">
            <motion.p 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 3, delay: 1 }}
              className="font-serif text-2xl md:text-3xl font-light text-white/90 italic"
            >
              We found something.
            </motion.p>
            <motion.p 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 3, delay: 4 }}
              className="font-serif text-2xl md:text-3xl font-light text-white/60 italic"
            >
              Your future left something for you.
            </motion.p>
          </div>
        </motion.div>
      )}

      {step === 'artifact' && (
        <motion.div 
          key="artifact"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 3, delay: 0.5 }}
          className="max-w-2xl w-full mx-auto py-32 flex flex-col items-center min-h-[80vh] justify-center"
        >
          <div className="flex flex-col items-center text-center space-y-16">
            
            <div className="space-y-8">
              <h3 className="font-serif italic text-2xl md:text-4xl text-white/30 font-light mix-blend-screen">
                Waiting for the timeline.
              </h3>
              <p className="font-mono text-[9px] tracking-[0.4em] uppercase text-white/10">
                You almost forgot this feeling.
              </p>
            </div>

            <div className="mt-32">
              <div className="text-[9px] font-mono tracking-[0.4em] uppercase text-white/10 mb-12 border-b border-white/5 pb-4 px-8 inline-block">Resurfaced Artifacts</div>
              <div className="space-y-1 w-64 mx-auto">
                {FUTURE_SCENES.map((scene) => (
                  <div
                    key={scene.id}
                    onClick={() => setActiveSceneId(scene.id)}
                    className="group flex flex-col items-center py-5 cursor-pointer"
                  >
                    <span className="font-serif text-sm md:text-base italic text-white/40 group-hover:text-white/80 transition-colors duration-1000">{scene.type}</span>
                    <div className="w-0 h-[1px] bg-white/20 group-hover:w-12 transition-all duration-1000 mt-3" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      </AnimatePresence>

      {/* Cinematic Future Scene Overlay */}
      <AnimatePresence>
      {activeScene && (
        <motion.div 
          key="overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, filter: "blur(10px)" }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
          className="fixed inset-0 z-50 bg-black text-white flex flex-col justify-center px-6 md:px-24"
        >
          <button 
            onClick={() => setActiveSceneId(null)}
            className="absolute top-12 left-1/2 -translate-x-1/2 text-[9px] font-mono tracking-[0.4em] uppercase text-white/20 hover:text-white/60 transition-colors duration-1000 p-4 z-50 mix-blend-difference"
          >
            Return
          </button>
          
          <div className="max-w-xl mx-auto w-full relative z-10">
            {activeScene.context && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 2, delay: 0.5 }}
                className="mb-20 font-mono text-[9px] tracking-[0.4em] text-white/30 uppercase text-center"
              >
                {activeScene.context}
              </motion.div>
            )}
            
            <div className="space-y-12 text-center px-4">
              {activeScene.content.split('\n\n').map((paragraph, i) => (
                <motion.p 
                  key={i} 
                  initial={{ opacity: 0, filter: "blur(8px)", y: 5 }}
                  animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                  transition={{ duration: 3, delay: (i * 1.5) + 1.5, ease: "easeOut" }}
                  className="font-serif text-2xl md:text-3xl text-white/80 font-light leading-relaxed italic"
                >
                  {paragraph}
                </motion.p>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 4, delay: activeScene.content.split('\n\n').length * 1.5 + 4 }}
              className="mt-32 pt-12 border-t border-white/5 font-serif italic text-sm text-white/30 text-center"
            >
              You almost forgot this feeling.
            </motion.div>
          </div>
          
          <div className="pointer-events-none absolute inset-0 z-0 w-full h-full opacity-[0.04] mix-blend-overlay" style={{ backgroundImage: 'url("https://grainy-gradients.vercel.app/noise.svg")' }} />
        </motion.div>
      )}
      </AnimatePresence>
    </div>
  );
}
