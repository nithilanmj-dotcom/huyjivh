export type ViewMode = 'blueprint' | 'mvp';

export interface OnboardingQuestion {
  id: string;
  category: string;
  question: string;
  description: string;
  options?: string[];
  type: 'text' | 'choice' | 'multi-choice';
}

export interface FutureScene {
  id: string;
  type: string;
  context?: string;
  content: string;
}

export type SceneType = 'Aspiration' | 'Relief' | 'Validation' | 'Quiet Confidence' | 'Alternate Timeline';
