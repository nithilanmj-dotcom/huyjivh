import { MVPView } from './components/MVPView';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-white/10 selection:text-white">
      <main className="relative z-10 w-full h-full">
        <MVPView />
      </main>

      {/* Brutalist Grain Overlay */}
      <div className="pointer-events-none fixed inset-0 z-50 h-full w-full opacity-[0.03] mix-blend-difference" style={{ backgroundImage: 'url("https://grainy-gradients.vercel.app/noise.svg")' }} />
    </div>
  );
}
